
import React from 'react';

function App() {
  return (
    <div>
      <h1>AI QUANT Dashboard</h1>
      <p>Tracking SPX Index and Options</p>
    </div>
  );
}

export default App;
